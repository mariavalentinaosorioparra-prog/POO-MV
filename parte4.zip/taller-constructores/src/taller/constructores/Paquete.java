/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package taller.constructores;

/**
 *
 * @author PC
 */
public class Paquete {

    String codigo;
    String destino;
    double peso;
    boolean asegurado;

    double costo;

    public Paquete(String codigo, String destino, double peso, boolean asegurado) {
        this.codigo = codigo;
        this.destino = destino;
        this.peso = peso;
        this.asegurado = asegurado;
    }

    public Paquete(String codigo, String destino) {
        this(codigo, destino, 1.0, false);
    }

    public Paquete(String codigo) {
        this(codigo, "Por asignar");
    }

    public void mostrarInformacion() {
        System.out.println(this.codigo + " -> " + this.destino + " | " + this.peso + " | asegurado: " + this.asegurado);
    }

    public void mostrarPeso(double peso) {
    }

    public double mostrarCosto() {

        if (peso == 1.0) {
           costo =+ 5000;
        }

        if (asegurado == true) {
         costo=+8000;   
        }
        
        return this.costo;
    }

}
