/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package habitacion;

/**
 *
 * @author PC
 */
public class Habitacion {

    private int numero;
    private String tipo;
    private double precioNoche;
    private boolean ocupada;

    
    public Habitacion(int numero, String tipo, double precioNoche, boolean ocupada) {
        this.numero = numero;
        this.tipo = tipo;
        this.precioNoche = precioNoche;
        this.ocupada = ocupada;
    }

    // Constructor con valores por defecto
    public Habitacion(int numero, String tipo) {
        this(numero, tipo, 120000, false);
    }

   
    public void ocupar() {
        ocupada = true;
    }

    public boolean estaDisponible() {
        return !ocupada;
    }

    public double calcularEstadia(int noches) {
        return precioNoche * noches;
    }

    public double calcularEstadia(int noches, double descuento) {
        double costo = calcularEstadia(noches);
        return costo - (costo * descuento / 100);
    }

    public void mostrarInformacion() {
        System.out.println("Número: " + numero);
        System.out.println("Tipo: " + tipo);
        System.out.println("Precio por noche: " + precioNoche);
        System.out.println("Ocupada: " + ocupada);
        System.out.println("Disponible: " + estaDisponible());
        System.out.println("--------------------------");
    }
}
