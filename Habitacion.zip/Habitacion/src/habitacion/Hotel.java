/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package habitacion;

/**
 *
 * @author PC
 */
public class Hotel {

    public static void main(String[] args) {

        Habitacion h1 = new Habitacion(101, "Individual");
        Habitacion h2 = new Habitacion(102, "Doble");

        Habitacion h3 = new Habitacion(201, "Suite", 200000, false);

        h2.ocupar();

        h1.mostrarInformacion();
        h2.mostrarInformacion();
        h3.mostrarInformacion();

        System.out.println("Estadía de h1 por 3 noches: "
                + h1.calcularEstadia(3));

        System.out.println("Estadía de h1 por 3 noches con 10% de descuento: "
                + h1.calcularEstadia(3, 10));
    }
}